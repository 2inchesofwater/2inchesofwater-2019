<footer>
	<section>
		<p>Copyright <?= date("Y") ?>. Dan Gilmore as 2 Inches of Water.</p>
	</section>
</footer>
<div class="site-frame"></div>
<div class="site-haze"></div> 
<link href="https://fonts.googleapis.com/css?family=Raleway:200,500" rel="stylesheet" type="text/css">
<?= css(['styles/css/index.css', '@auto']) ?>
<script type="text/javascript" src="<?= $site->url() ?>/assets/js/intersection-observer.js"></script>
<script type="text/javascript" src="<?= $site->url() ?>/assets/js/toggleMenu.js"></script>
<script type="text/javascript" src="<?= $site->url() ?>/assets/js/lazyLoading.js"></script>
</body>
</html>
